<?php
session_start(); // Access the existing session.

// This page is for editing a user record.
// This page is accessed through view_users.php.

$page_title = 'Edit info';

 require ('C:\xampp\htdocs\InternetP\Project1\mysqli_connect.php');

    
 // Check if the form has been submitted:
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$errors = array();
	
    // Check for a name:
	if (empty($_POST['name'])) {
		$errors[] = 'You forgot to enter user name.';
	} else {
		$n = trim($_POST['name']);
	}
	
	// Check for a  dob:
	if (empty($_POST['dob'])) {
		$errors[] = 'You forgot to enter user date of birth';
	} else {
		$dob = trim($_POST['dob']);
	}
    
	// Check for gender:
        if (empty($_POST['gender'])) {
            $errors[] = 'You forgot to choose user gender.';
          } else {
            $g = trim($_POST['gender']);
          }
        
	
	// Check for blood type:
	if (empty($_POST['bloodtype'])) {
		$errors[] = 'You forgot to select user blood type';
	} else {
		$bt = trim($_POST['bloodtype']);
	}
	
	// Check for email:
	if (empty($_POST['email'])) {
		$errors[] = 'You forgot to enter email.';
	} else {
		$email = trim($_POST['email']);
	}
	
	// Check for an phone:
	if (empty($_POST['phone'])) {
		$errors[] = 'You forgot to enter phone number.';
	} else {
		$phone = trim($_POST['phone']);
	}

		// Check for address:
	if (empty($_POST['address'])) {
		$errors[] = 'You forgot to enter address.';
	} else {
		$address = trim($_POST['address']);
	}
		// Check for address2:
	if (empty($_POST['address2'])) {
		$errors[] = 'You forgot to enter continuation of address';
	} else {
		$address2 = trim($_POST['address2']);
	}

    if (empty($errors)) { // If everything's OK.
      $id = $_SESSION['user_id'];
      echo $id;
				//  Test for unique email address:
          $q = "SELECT user_id FROM student WHERE email='$email' AND user_id != $id";
          $r = @mysqli_query($dbc, $sql);
     
          if(mysqli_num_rows($r)==1){
     
              $sql="UPDATE users SET name= '$n', dob= '$dob', gender='$g', bloodtype='$bt' phone='$phone', email='$email', address='$address', address2='$address2'WHERE user_id=$id LIMIT 1";
              $r=mysqli_query($dbc,$sql);
              if(mysqli_affected_rows($dbc)==1){
                  //successful update
               echo '<body>
               <section class="p-5 text-left mx-5">
         
                 <h1 class="text-center mb-5 my-3 ">User info updated!</h1>
         
                 
                 <div class="register-user wrapper text-left p-5" >
                 <h1>Thank you!</h1>
                 <p>You our info has been updated.</p>
                 </div>
                 </section>
               
               </body>';	
            }else{ //does not run ok
                echo '
                        <body>
                <section class="p-5 text-left mx-5">
                
                <h1 class="text-center mb-5 my-3 ">Edit user info</h1>
                <div class="register-user wrapper text-left p-5" >
                
                        <p class="error">The edit could not be edited due to a system error. We apologize for any inconvenience.</p> ';
                        
                    echo '<p>' . mysqli_error($dbc) . '<br />Query: ' . $q . '</p>
                
                    </div>
                    </section>
                  
                  </body>';
                } 
           }else{
            //already registered
            echo '<body>
            <section class="p-5 text-left mx-5">
      
              <h1 class="text-center mb-5 my-3 ">Edit user info</h1>
              <div class="register-user wrapper text-left p-5" >
              <p class="error">The information has already been inserted.</p>
              </div>
              </section>
            
            </body>';
           }
    
          }else { // Report the errors.
     
           echo '<body>
               <section class="p-5 text-left mx-5">
         
                 <h1 class="text-center mb-5 my-3 ">Edit user info</h1>
                 <div class="register-user wrapper text-left p-5" >
         <p class="error">The following error(s) occurred:<br />';
         
       
           foreach ($errors as $msg) { // Print each error.
             echo " - $msg<br />\n";
           }
           echo '</p><p>Please try again.</p>';
         
         } // End of if (empty($errors)) IF.
           echo'  </div>
           </section>
         
         </body>';
       
       } 
      

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
    rel="stylesheet" 
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
    crossorigin="anonymous">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

    
    <title>Profile setting</title>
</head>
<body>
      <!--Navigation Bar-->
   <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
    <div class="container">
        <img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>

      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navmenu"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navmenu">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a href="loggedin.php" class="nav-link">Home</a>
              </li>
            <li class="nav-item">
            <a href="setbooking.php" class="nav-link">Set Booking</a>
          </li>
          <li class="nav-item">
            <a href="logout.php" class="nav-link">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav> 

  <section class="p-5 text-center text-sm-start">

  <h1 class="text-center mb-5 my-3">Change user info</h1>

 <?php // Retrieve the user's information:
$q = "SELECT * FROM users WHERE user_id=".$row['user_id'];		
$r = @mysqli_query ($dbc, $q);

if (mysqli_num_rows($r) == 1) { // Valid user ID, show the form.

	// Get the user's information:
	$row = mysqli_fetch_array ($r, MYSQLI_NUM);
	?>
	        
<div class="change-user text-left p-5" >
  <h3>Fillout this form</h3>
  <form action="editinfo.php" method="POST">

    <!--Name-->
    <div class="col-20">
              <div class="mb-3">
                <label for="name" class="col-form-label">
                    Name:
                </label>
                <div class="textbox">
                  <input type="text" style="width: 500px" class="form-control form-width" 
				  placeholder="Name stated in your IC / Passport" name="name"
				  value="<?php if (isset($_POST['name'])) echo $_POST['name'];?>">
                 </div>
               </div>
            </div>

              <!--Date of birth as calendar-->
              <div class="col-20">
                <div class="mb-3">
                  <label for="date-birth" class="col-form-label" >
                      Date of birth:
                  </label>
                  <div class="textbox">
                    <input type="text" style="width: 250px"class="form-control form-width"
					placeholder="DD-MM-YYYY" name="dob"
					value="<?php if (isset($_POST['dob'])) echo $_POST['dob']; ?>">
                
                  </div>
                </div>
              </div>

              <!--bloodtype-->
              <div class="col-20">
                <div class="mb-3">
                  <label for="blood-type" class="col-form-label">
                      Blood type:
                  </label>
                  <?php 
	
					if (isset($_POST['bloodtype'])) echo $_POST['bloodtype'];
					// This script make apull-down menus for an HTML form: programmes.
					// Make the programme array.
					$bloodtype = array (1 =>'O Rh+', 'O Rh-', 'A Rh+','A Rh-', 'B Rh+','B Rh-', 'AB Rh+', 'AB Rh-');
					// Make the program pull-down menu.
				
					echo '<select name="bloodtype">';
					foreach ($bloodtype as $key=> $value) {
					echo "<option value=\"$value\">$value</option>\n";
					}
					echo '</select>';?>
                </div>
              </div>


              <!--Gender-->

              <div class="col-20">
                <div class="mb-3">
                  <label for="Gender" class="col-form-label">
                    Gender:
                  </label>
                  <?php if (isset($_POST['gender'])) echo $_POST['gender'];?>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="gender" value="m" checked>
                    <label class="form-check-label" for="flexRadioDefault1">
                      Male
                    </label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="gender" value="f">
                    <label class="form-check-label" for="flexRadioDefault2">
                      Female
                    </label>
                  </div>
                </div>
              </div>
    <!--Email-->
    <div class="col-20">
      <div class="mb-3">
        <label for="email" class="col-form-label">
            Email:
        </label>
            <div class="textbox">
                <input style="width: 500px" type="text" class="form-control form-width" 
                placeholder="Email" name="email"
                value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>">
             </div>
       </div>
    </div>
    <!--phone number-->
    <div class="col-20">
      <div class="mb-3">
        <label for="phone" class="col-form-label">
            Phone:
        </label>
            <div class="textbox">
                <input style="width: 250px" type="text" class="form-control form-width" 
                placeholder="eg 673 xxx xxxx" name="phone"
                value="<?php if (isset($_POST['phone'])) echo $_POST['phone']; ?>">
             </div>
       </div>
    </div>
    <!--address-->
    <div class="col-20">
      <div class="mb-3">
        <label for="name" class="col-form-label">
            Home Address:
        </label>
            <div class="textbox">
                <input style="width: 500px" type="text" class="form-control form-width" 
                placeholder="Address" name="address"
                value="<?php if (isset($_POST['address'])) echo $_POST['address']; ?>">
             </div>
       </div>
    </div>
    <!--address2-->
    <div class="col-20">
      <div class="mb-3">
        
            <div class="textbox">
                <input style="width: 500px" type="text" class="form-control form-width" 
                placeholder="Address, if empty put '-'" name="address2"
                value="<?php if (isset($_POST['address2'])) echo $_POST['address2']; ?>">
             </div>
       </div>
    </div>
    <input type="submit" href="editinfo.php" class="update profile btn btn-primary" id="updateprofile" value="Update profile" > </input>
    <input type="hidden" name="id" value="' . $id . '" />
    <a href="psetting.php" class="cancel btn btn-danger" id="cancel" value="Cancel" > Cancel </a>
    <?php
  }
  
  mysqli_close($dbc);?>
                    
</form>
  </section>
             <!--Footer-->
           <footer class="p-5 bg-dark text-white text-left position-relative">
    <div class="container">
        <p class="lead">Copyright &copy; 2022 Blood Bank Brunei UniKL.FYP2-AmalNaqibah52213118385</p>
    
        <a href="" class="position-absolute bottom-0 end-0 p-5">
            <i class="bi bi-arrow-up-circle h1"></i>
        </a>
    </div>
    </footer>
</body>
</html>