
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
          rel="stylesheet" 
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
          crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

    <title>View staff</title>
</head>
<body>
    
<!--Navigation Bar-->
<nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
        <div class="container">
          <img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>
  
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navmenu"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
  
          <div class="collapse navbar-collapse" id="navmenu">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                <a href="loggedin_pageadmin.php" class="nav-link">Home</a>
              </li>
              <li class="nav-item">
                <a href="viewschedule.php" class="nav-link">Schedules</a>
              </li>
              <li class="nav-item">
                <a href="viewusers.php" class="nav-link">Users</a>
              </li>
              <li class="nav-item">
                <a href="adminlogout.php" class="nav-link">Logout</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>



       <!--Showcase functions-->
            
       <section class="first-row bg-light p-5 text-center text-sm-start mt-5">
            <div class="4-boxes">
                <div class="container">
                    <div class="d-sm-flex align-items-center justify-content-between">
                        <div>
                            <h1>Blood Bank Brunei
                            <span class="text-warning">Staff</span></h1>
                            <p class="lead my-2">This is the staff page where you can edit, remove and add staff.</p>
                        </div>
                        <img class="img-fluid w-60 d-none d-sm-block" 
                        src="img/bloodlogo4.png" alt="">
                    </div>
                </div>
            </div>
        </section>

      <!--Searchbar-->
      <div class="wrapper p-5 mt-5 bg-light">
            <form action="" class="navbar-form">
                  <div class="form-group">
                      <input style="width: 700px" type="text" class="form-control form-width" placeholder="Search....">
                  </div>
                  <button class="btn btn-dark" type="submit">Search</button>
            </form>
      </div>

      <div class="newuser p-4">
        <form action="registerstaff.php" method="">
        <button class="btn btn-primary p-4 my-2">Add new staff</button>
        </form>
      </div>
      <!--table-->

<?php
require ('../mysqli_connect.php');
    $q = "SELECT * FROM staff ORDER BY s_name";
    $r= @mysqli_query ($dbc, $q);

    //Count number of users

    $num = mysqli_num_rows ($r);

    if ($num > 0) {

       

      //if booking present

      echo '<section class="p-5">
      
          <div class="align-items-center justify-content-between">';
          echo"<h2>There are $num of staff members.</h2>";
          echo'<div class="table">
              <table class="table table-dark table-striped">
                
                  <thead>
                      <tr>
                          <!--Row 1-->
                        <th scope="col">Id</th>
                        <th scope="col">Name</th>
                        <th scope="col">Date of birth</th>
                        <th scope="col">Phone No.</th>
                        <th scope="col">Address</th>
                        <th scope="col">Email</th>
                        <th scope="col" colspan="2"></th>
                        
                      </tr>
                    </thead>';

                      while ($row = mysqli_fetch_array ($r, MYSQLI_ASSOC)){

                        echo '<tbody>
                        <tr> 
                            <!--Row 2-->
                          <th scope="row">' . $row ['staff_id'] . ' </th>
                          <td scope="row">' . $row ['s_name'] . '</td>
                          <td scope="row">' . $row ['s_dob'] . '</td>
                          <td scope="row">' . $row ['s_phone'] . '</td>
                          <td scope="row">' . $row ['s_address'] . '</td>
                          <td scope="row">' . $row ['s_email'] . '</td>
                          <td><button class="btn btn-success">Edit</button></td>
                          <td><button class="btn btn-danger">Delete</button></td>
                          
                        </tr>';
                      }
                      echo '</table>';
                      mysqli_free_result ($r);

      
    } else {
      //if booking is empty

      echo '<section class="p-5">
      
          <div class="align-items-center justify-content-between">
          <div class="table">
              <table class="table table-dark table-striped">
                
                  <thead>
                      <tr>
                          <!--Row 1-->
                          <th scope="col">Staff Id</th>
                          <th scope="col">Name</th>
                          <th scope="col">Date of birth</th>
                          <th scope="col">Phone</th>
                          <th scope="col">Email</th>
                          <th scope="col">Address</th>
                          <th scope="col">Address cont.</th>
                          <th><button class="btn btn-success">Manage bookings</button></th>
                  
                      </tr>
                    </thead>
                    <tbody>
                      <tr> 
                          <!--Row 2-->
                        <th scope="row" colspan="6">There are no users.</th>
                        
                      </tr>
                      
                      </table>
          </div>
          </div>
      </div>
  </section>';
    }

    mysqli_close($dbc);
     
    ?>


<!--Footer-->
<footer class="p-5 bg-dark text-white text-left position-relative">
    <div class="container">
        <p class="lead">Copyright &copy; 2022 Blood Bank Brunei UniKL.FYP2-AmalNaqibah52213118385</p>
    
        <a href="" class="position-absolute bottom-0 end-0 p-5">
            <i class="bi bi-arrow-up-circle h1"></i>
        </a>
    </div>
    </footer>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>
</html>