
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
          rel="stylesheet" 
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
          crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

    
    <title>Admin</title>
</head>
<body>

    <!--Navigation Bar-->
    <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
        <div class="container">
          <img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>
  
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navmenu"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
  
          <div class="collapse navbar-collapse" id="navmenu">
            <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a href="viewstaff.php" class="nav-link">Staff</a>
              </li>
              <li class="nav-item">
                <a href="viewschedule.php" class="nav-link">Schedules</a>
              </li>
              <li class="nav-item">
                <a href="viewusers.php" class="nav-link">Users</a>
              </li>
              <li class="nav-item">
                <a href="adminlogout.php" class="nav-link">Logout</a>
            </ul>
          </div>
        </div>
      </nav>

      <!--Showcase functions-->
            
        <section class="first-row bg-light p-5 text-center text-sm-start mt-5">
            <div class="4-boxes">
                <div class="container">
                    <div class="d-sm-flex align-items-center justify-content-between">
                        <div>
                            <h1>Blood Bank Brunei
                            <span class="text-warning">Admin</span></h1>
                            <p class="lead my-2">Administrator page where we can see users, staff, schedules for donations and schedule changes from users.</p>
                                <p class="lead my-2">The user page and staff page will have a CRUD function in the table whether to add new users, update user info and delete.</p>
                                 <p class="lead my-2">The schedule page is filled with schedule that is prioritized by the month it is in </p>
                            
                        </div>
                        <img class="img-fluid w-60 d-none d-sm-block" 
                        src="img/bloodlogo4.png" alt="">
                    </div>
                </div>
            </div>
        </section>


    
        <!--Boxes function-->
    <section class="p-5">

        <h1 class="my-3 mb-5 text-center text-black" >Admin</h1>

    <div class="container">
        <div class="row text-center g-4" >
            <div class="col-md">
                <div class="card bg-dark text-light">
                    <div class="card-body text-center">
                        <div class="h1 mb-3">
                            <i class="bi bi-laptop"></i>
                        </div>
                        <h3 class="card-title mb-3">View users</h3>
                        <p class="card-text">Update user information</p>
                        <a href="viewusers.php" class="btn btn-primary">View</a>
                    </div>
                </div>
            </div>
            <div class="col-md">
                <div class="card bg-dark text-light">
                    <div class="card-body text-center">
                        <div class="h1 mb-3">
                            <i class="bi bi-laptop"></i>
                        </div>
                        <h3 class="card-title mb-3">View bookings</h3>
                        <p class="card-text">View booking for this month</p>
                        <a href="viewschedule.php" class="btn btn-primary">View</a>
                    </div>
                </div>
            </div>
            <div class="col-md">
                <div class="card bg-dark text-light">
                    <div class="card-body text-center">
                        <div class="h1 mb-3">
                            <i class="bi bi-laptop"></i>
                        </div>
                        <h3 class="card-title mb-3">View staff</h3>
                        <p class="card-text">Update staff information</p>
                        <a href="viewstaff.php" class="btn btn-primary">View</a>
                    </div>
                </div>
            </div> 
        </div>
    </div>
</section>

<!--Footer-->
<footer class="p-5 bg-dark text-white text-left position-relative">
    <div class="container">
        <p class="lead">Copyright &copy; 2022 Blood Bank Brunei UniKL.FYP2-AmalNaqibah52213118385</p>
    
        <a href="" class="position-absolute bottom-0 end-0 p-5">
            <i class="bi bi-arrow-up-circle h1"></i>
        </a>
    </div>
    </footer>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>
</html>