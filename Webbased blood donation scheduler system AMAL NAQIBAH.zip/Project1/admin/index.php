<?php # Script 12.1 - .inc.php
// This page prints any errors associated with logging in
// and it creates the entire login page, including the form.

// Include the header:
$page_title = 'Login';


// Print any error messages, if they exist:
if (isset($errors) && !empty($errors)) {
	echo '<body>
      <section class="p-5 text-left mx-5 ">
        <h1 class="text-center mb-5 my-3 ">Login</h1>
        <div class="register-user bg-light text-left p-5 " >
        <h1>Please try again</h1>
		  <p class="error">The following error(s) occurred:<br />';
		  foreach ($errors as $msg) { // Print each error.
			echo " - $msg<br />\n";
	  	}
		  echo '        
       </div>
        </section>
      
      </body>';
}

?>

<form action="loginadmin.php" method="post">
	<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
          rel="stylesheet" 
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
          crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

    
    <title>Login</title>
</head>
<body>
        <!--Navigation Bar-->
        <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
            <div class="container">
              <img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>

              <button
                class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navmenu"
              >
               
              </div>
            </div>
          </nav>

          <!--Login form-->

          <section class="p-5 text-center mt-5">

            <h1 class="text-center-mb-5 my-3"> Login</h1>

            <div class="login form-login"  style="text-align: center">
              <p class="lead">Login to manage user accounts and bookings</p>
          <form method="POST" action="loginadmin.php">
              <div class="form-row align-items-center">
                
                  <input 
                  type="email" 
                  placeholder="Email Address" 
                  class="form-control my-4 text"
				  name="semail">
              </div>
             
              <div class="form-row align-items-center">
                
                  <input 
                  type="password" 
                  placeholder="**************" 
                  class="form-control form-width my-1"
				  name="password">
              </div>
             
              <div class="form-row my-2">
                <a href="#" class="forgotpassword text-link" data-bs-toggle="modal" data-bs-target="#forgotpass" >Forgot your password?</a>
              </div>
              
			  <input type="submit" class="btn btn-light my-4" value="Login"></input>
          </form>
          
            </div>
            
              
             

          </section>

          <!--Footer-->
<footer class="p-5 bg-dark wrapper text-white text-left position-relative">
  <div class="container">
      <p class="lead">Copyright &copy; 2022 Blood Bank Brunei UniKL.FYP2-AmalNaqibah52213118385</p>
  
      <a href="" class="position-absolute bottom-0 end-0 p-5">
          <i class="bi bi-arrow-up-circle h1"></i>
      </a>
  </div>
  </footer>
  
<!-- Modal forgot pass -->
<div class="modal fade" id="forgotpass" tabindex="-1" aria-labelledby="forgotpassLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="forgotpassLabel">Forgot your password?</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          
        </div>
        <div class="modal-body">
            <p class="lead">PLease contact the administrator of your workplace to recover password</p>

          <form action="sendmail.php" method="post">
              <div class="mb-3">
               <label for="email" class="col-form-label">
                      Email information : admin@bloodbankbrunei.com.bn
                  </label>
               <label for="email" class="col-form-label">
                      Contact info : xxx-xxxx
                  </label>
                  
              </div>
			   <div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
				</div>
          </form>
        </div>
        
      </div>
    </div>
  </div>

          <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>
</html>
</form>