<?php 

// This page processes the login form submission.
// The script now uses sessions.

// Check if the form has been submitted:
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	// Need two helper files:
	require ('C:\xampp\htdocs\InternetP\Project1\admin\login_functions_admin.inc.php');
	require ('../mysqli_connect.php');
		
	// Check the login:
	list ($check, $data) = check_login($dbc, $_REQUEST['semail'], $_REQUEST['password']);
	
	if ($check) { // OK!
		
		// Set the session data:
		session_start();
		$_SESSION['staff_id'] = $data['staff_id'];
		$_SESSION['s_name'] = $data['s_name'];
		$_SESSION['s_dob'] = $data['s_dob'];
		$_SESSION['s_phone'] = $data['s_phone'];
		$_SESSION['s_email'] = $data['s_email'];
		$_SESSION['s_address'] = $data['s_address'];
				
		// Redirect:
		redirect_user('loggedin_pageadmin.php');
			
	} else { // Unsuccessful!

		// Assign $data to $errors for login_page.inc.php:
		$errors = $data;

	}
		
	mysqli_close($dbc); // Close the database connection.

} // End of the main submit conditional.

// Create the page:
include ('C:\xampp\htdocs\InternetP\Project1\admin\index.php');
?>