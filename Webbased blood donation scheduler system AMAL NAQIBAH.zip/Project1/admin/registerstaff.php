<?php 
// This script performs an INSERT query to add a record to the users table.

session_start(); // Access the existing session.


$page_title = 'Register staff';


// Check for form submission:
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$errors = array(); // Initialize an error array.
	
	// Check for a name:
	if (empty($_POST['s_name'])) {
		$errors[] = 'You forgot to enter staff name.';
	} else {
		$n = trim($_POST['s_name']);
	}
	
	// Check for a  dob:
	if (empty($_POST['s_dob'])) {
		$errors[] = 'You forgot to enter staff date of birth';
	} else {
		$dob = trim($_POST['s_dob']);
	}
	
	
	// Check for phone no:
	if (empty($_POST['s_phone'])) {
		$errors[] = 'You forgot to enter staff date phone number';
	} else {
		$ph = trim($_POST['s_phone']);
	}
	
	// Check for an email address:
	if (empty($_POST['s_email'])) {
		$errors[] = 'You forgot to enter staff email address.';
	} else {
		$e = trim($_POST['s_email']);
	}

  	// Check for an address:
	if (empty($_POST['s_address'])) {
		$errors[] = 'You forgot to enter your address.';
	} else {
		$ad1 = trim($_POST['s_address']);
	} 
	
	// Check for a password:
	if (!empty($_POST['s_password'])) {
        if ($_POST['s_password'] != $_POST['pass2']) {
            $errors[] = 'Your password did not match the confirmed password.';
        } else {
            $p = trim($_POST['s_password']);
        }
    } else {
        $errors[] = 'You forgot to enter your password.';
    }	
	
	
	if (empty($errors)) { // If everything's OK. ($fn && $ln && $pn && $e)
	
		// Register the user in the database...
		
		require ('../mysqli_connect.php'); // Connect to the db.

		// Make the query:
		$q = "INSERT INTO staff (s_name, s_dob, s_phone, s_address,s_email, s_password) VALUES ('$n', '$dob','$ph', '$ad1','$e', SHA1('$p')";		
		$r = mysqli_query ($dbc, $q); // Run the query.
		if ($r) { // If it ran OK.

			// Print a message:
			echo '<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
                      rel="stylesheet" 
                      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
                      crossorigin="anonymous">
                <link rel="stylesheet" href="style.css">
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
            
                <title>Register staff</title>
            </head>
            <body>
                
            <!--Navigation Bar-->
            <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
                    <div class="container">
                      <img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>
              
                      <button
                        class="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navmenu"
                      >
                        <span class="navbar-toggler-icon"></span>
                      </button>
              
                      <div class="collapse navbar-collapse" id="navmenu">
                        <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a href="loggedin_pageadmin.php" class="nav-link">Home</a>
                          </li>
                          <li class="nav-item">
                            <a href="viewstaff.php" class="nav-link">Staff</a>
                          </li>
                          <li class="nav-item">
                            <a href="viewusers.php" class="nav-link">Users</a>
                          </li>
                          <li class="nav-item">
                            <a href="adminlogout.php" class="nav-link">Logout</a>
                        </ul>
                      </div>
                    </div>
                  </nav>
      <section class="p-5 text-left mx-5">

        <h1 class="text-center mb-5 my-3">Register</h1>

        
        <div class="register-user wrapper text-left p-5" >
        <h1>User has been registered!</h1>
        <a href="viewstaff.php" class="nav-link">Return to staff table</a>
        </div>
        </section>
        <!--Footer-->
<footer class="p-5 bg-dark text-white text-left position-relative">
    <div class="container">
        <p class="lead">Copyright &copy; 2022 Blood Bank Brunei UniKL.FYP2-AmalNaqibah52213118385</p>
    
        <a href="" class="position-absolute bottom-0 end-0 p-5">
            <i class="bi bi-arrow-up-circle h1"></i>
        </a>
    </div>
    </footer>

        <script src="jquery.datetimepicker.full.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        
      </body>';
		
		

		} else { // If it did not run OK.
	
			// Public message:
			echo '<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
                      rel="stylesheet" 
                      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
                      crossorigin="anonymous">
                <link rel="stylesheet" href="style.css">
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
            
                <title>Register</title>
            </head>
            <body>
                
            <!--Navigation Bar-->
            <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
                    <div class="container">
                      <img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>
              
                      <button
                        class="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navmenu"
                      >
                        <span class="navbar-toggler-icon"></span>
                      </button>
              
                      <div class="collapse navbar-collapse" id="navmenu">
                        <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a href="loggedin_pageadmin.php" class="nav-link">Home</a>
                          </li>
                          <li class="nav-item">
                            <a href="viewstaff.php" class="nav-link">Staff</a>
                          </li>
                          <li class="nav-item">
                            <a href="viewusers.php" class="nav-link">Users</a>
                          </li>
                          <li class="nav-item">
                            <a href="adminlogout.php" class="nav-link">Logout</a>
                        </ul>
                      </div>
                    </div>
                  </nav>
      <section class="p-5 text-left mx-5">

        <h1 class="text-center mb-5 my-3">Register</h1>
        <div class="register-user wrapper text-left p-5" >

        <h1>System Error</h1>
			<p class="error">staff could not be registered due to a system error. We apologize for any inconvenience.</p>
      
      </div>
        </section>
        <!--Footer-->
<footer class="p-5 bg-dark text-white text-left position-relative">
    <div class="container">
        <p class="lead">Copyright &copy; 2022 Blood Bank Brunei UniKL.FYP2-AmalNaqibah52213118385</p>
    
        <a href="" class="position-absolute bottom-0 end-0 p-5">
            <i class="bi bi-arrow-up-circle h1"></i>
        </a>
    </div>
    </footer>

        <script src="jquery.datetimepicker.full.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        
      </body>';	
			// Debugging message:
			echo '<p>' . mysqli_error($dbc) . '<br /><br />Query: ' . $q . '</p>';
				
		} // End of if ($r) IF.
		
		mysqli_close($dbc); // Close the database connection.
		
		// Include the footer and quit the script:
		
		exit();
		
	} else { // Report the errors.
	
		echo '<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
                  rel="stylesheet" 
                  integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
                  crossorigin="anonymous">
            <link rel="stylesheet" href="style.css">
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        
            <title>View schedule</title>
        </head>
        <body>
            
        <!--Navigation Bar-->
        <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
                <div class="container">
                  <img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>
          
                  <button
                    class="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navmenu"
                  >
                    <span class="navbar-toggler-icon"></span>
                  </button>
          
                  <div class="collapse navbar-collapse" id="navmenu">
                    <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a href="loggedin_pageadmin.php" class="nav-link">Home</a>
                      </li>
                      <li class="nav-item">
                        <a href="viewstaff.php" class="nav-link">Staff</a>
                      </li>
                      <li class="nav-item">
                        <a href="viewusers.php" class="nav-link">Users</a>
                      </li>
                      <li class="nav-item">
                        <a href="adminlogout.php" class="nav-link">Logout</a>
                    </ul>
                  </div>
                </div>
              </nav>
      <section class="p-5 text-left mx-5">
        <h1 class="text-center mb-5 my-3 text-light">Register</h1>
        <div class="register-user wrapper text-left p-5" >
        <h1>Please try again below.</h1>
		  <p class="error">The following error(s) occurred:<br />';
		  foreach ($errors as $msg) { // Print each error.
			echo " - $msg<br />\n";
	  	}
		  echo '        
       </div>
        </section>
        

        <script src="jquery.datetimepicker.full.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        
      </body>';
		
	} // End of if (empty($errors)) IF.

} // End of the main Submit conditional.
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
          rel="stylesheet" 
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
          crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

    
    <title>Register</title>
</head>
<body>
  
     <!--Navigation Bar-->
     <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
        <div class="container">
          <img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>

          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navmenu"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
  
          <div class="collapse navbar-collapse" id="navmenu">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                <a href="loggedin_pageadmin.php" class="nav-link">Home</a>
              </li>              
              <li class="nav-item">
                <a href="viewstaff.php" class="nav-link">Staff</a>
              </li>
              <li class="nav-item">
                <a href="viewusers.php" class="nav-link">Users</a>
              </li>
              <li class="nav-item">
                <a href="adminlogout.php" class="nav-link">Logout</a>
            </ul>
            </ul>
          </div>
        </div>
      </nav>  
      

      <!--register-->
      <section class="p-5 text-left mx-5 " >

        <h1 class="text-center mb-5 my-3">Register</h1>

        
        <div class="register-user text-left p-5" >
          <h3>Fillout this form</h3>
          <form action="registerstaff.php" method="POST">
            <!--Name-->
            <div class="col-20">
              <div class="mb-3">
                <label for="name" class="col-form-label">
                    Name:
                </label>
                <div class="textbox">
                  <input type="text" style="width: 500px" class="form-control form-width" 
				  placeholder="Name stated in IC / Passport" name="s_name"
				  value="<?php if (isset($_POST['s_name'])) echo $_POST['s_name'];?>">
                 </div>
               </div>
            </div>

              <!--Date of birth as calendar-->
              <div class="col-20">
                <div class="mb-3">
                  <label for="date-birth" class="col-form-label" >
                      Date of birth:
                  </label>
                  <div class="textbox">
                    <input type="text" style="width: 250px"class="form-control form-width"
					placeholder="DD-MM-YYYY" name="s_dob"
					value="<?php if (isset($_POST['s_dob'])) echo $_POST['s_dob']; ?>">
                
                  </div>
                </div>
              </div>

              <!--Phone No.-->
              <div class="col-20">
                <div class="mb-3">
                  <label for="phone-no" class="col-form-label">
                      Phone. No:
                  </label>
                  <div class="textbox">
                    <input type="text" style="width: 250px"class="form-control form-width" placeholder="673-xxx-xxxx" 
					name="s_phone" value="<?php if (isset($_POST['s_phone'])) echo $_POST['s_phone']; ?>">
                
                  </div>
                </div>
              </div>

              <!--Address-->

              <div class="col-20">
                <div class="mb-3">
                  <label for="address" class="col-form-label">
                    Address:
                  </label>

                  <div class="textbox">
                    <input type="text" style="width: 500px" class="form-control form-width" 
					placeholder="Enter your address" name="s_address"
					value="<?php if (isset($_POST['s_address'])) echo $_POST['s_address']; ?>">
                
                  </div>
                </div>
              </div>
              <!--email-->
              <div class="col-20">
                <div class="mb-3">
                  <label for="email" class="col-form-label">
                      Email:
                  </label>
                  <div class="textbox">
                    <input type="text" style="width: 350px"class="form-control form-width" 
					placeholder="Enter your email" name="s_email"
					value="<?php if (isset($_POST['s_email'])) echo $_POST['s_email']; ?>">
                
                  </div>
                </div>
              </div>

              <!--passwords-->
            <div class="col-20">
              <div class="mb-3">
                <label for="password" class="col-form-label">
                    Password:
                </label>
                <div class="textbox">
                  <input type="password" style="width: 500px" class="form-control form-width" 
				  placeholder="Enter at least 8 characters" name="s_password"
				  value="<?php if (isset($_POST['s_password'])) echo $_POST['s_password']; ?>">
              
                </div>
              </div>
            </div>
            
            <div class="col-20">
              <div class="mb-3">
                <label for="confirm-pass" class="col-form-label">
                    Confirm Password:
                </label>
                <div class="textbox">
                  <input type="password" style="width: 500px" class="form-control form-width" 
				  placeholder="Must be the same from the 'Password'"name="pass2"
				  value="<?php if (isset($_POST['pass2'])) echo $_POST['pass2']; ?>">
              
                </div>
                </div>
            </div>
          </table>
            
          <div class="buttonsubmit text-center  ">
            <input type="submit" class="btn btn-primary" value="Register"></input>
          </div> 
          </form>
          

        </div>
      </section>

<!--Footer-->
<footer class="p-5 bg-dark text-white text-left position-relative">
    <div class="container">
        <p class="lead">Copyright &copy; 2022 Blood Bank Brunei UniKL.FYP2-AmalNaqibah52213118385</p>
    
        <a href="" class="position-absolute bottom-0 end-0 p-5">
            <i class="bi bi-arrow-up-circle h1"></i>
        </a>
    </div>
    </footer>

    <script src="jquery.datetimepicker.full.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    
</body>
</html>
