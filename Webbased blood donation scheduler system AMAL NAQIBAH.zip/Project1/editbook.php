<?php 
session_start(); // Access the existing session.
if (!isset($_SESSION['user_id'])) {
	require('includes/login_functions.inc.php');
        redirect_user();
}
// This page is for editing a user record.
// This page is accessed through view_users.php.

$page_title = 'Edit a Book';
include ('includes/header.html');
echo '<h1>Edit a Book</h1>';

// Check for a valid user ID, through GET or POST:
if ( (isset($_GET['id'])) && (is_numeric($_GET['id'])) ) { // From view_users.php
	$id = $_GET['id'];
} elseif ( (isset($_POST['id'])) && (is_numeric($_POST['id'])) ) { // Form submission.
	$id = $_POST['id'];
} else { // No valid ID, kill the script.
	echo '<p class="error">This page has been accessed in error.</p>';
	include ('includes/footer.html'); 
	exit();
}

require ('../mysqli_connect.php'); 

// Check if the form has been submitted:
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$errors = array();
	
	// Check for book title:
	if (empty($_POST['title'])) {
		$errors[] = 'You forgot to enter book title.';
	} else {
		$t = trim($_POST['title']);
	}
	
	// Check for an author:
	if (empty($_POST['author'])) {
		$errors[] = 'You forgot to enter book author.';
	} else {
		$a = trim($_POST['author']);
	}

		// Check for category:
	if (empty($_POST['email'])) {
		$errors[] = 'You forgot to enter book category.';
	} else {
		$c = trim($_POST['category']);
	}
		// Check for book information:
	if (empty($_POST['bookinfo'])) {
		$errors[] = 'You forgot to enter the book information.';
	} else {
		$b = trim($_POST['bookinfo']);
	}
	
	
	if (empty($errors)) { // If everything's OK.
	
		//  Test for unique email address:
		$q = "SELECT user_id FROM books WHERE title='$t' AND user_id != $id";
		$r = @mysqli_query($dbc, $q);
		if (mysqli_num_rows($r) == 0) {

			// Make the query:
			$q = "UPDATE books SET title='$t', author='$a', category='$c', bookinfo='$b'  WHERE user_id=$id LIMIT 1";
			$r = @mysqli_query ($dbc, $q);
			if (mysqli_affected_rows($dbc) == 1) { // If it ran OK.

				// Print a message:
				echo '<p>The book has been edited.</p>';	
				
			} else { // If it did not run OK.
				echo '<p class="error">The book could not be edited due to a system error. We apologize for any inconvenience.</p>'; // Public message.
				echo '<p>' . mysqli_error($dbc) . '<br />Query: ' . $q . '</p>'; // Debugging message.
			}
				
		} else { // Already registered.
			echo '<p class="error">The book has already been inserted.</p>';
		}
		
	} else { // Report the errors.

		echo '<p class="error">The following error(s) occurred:<br />';
		foreach ($errors as $msg) { // Print each error.
			echo " - $msg<br />\n";
		}
		echo '</p><p>Please try again.</p>';
	
	} // End of if (empty($errors)) IF.

} // End of submit conditional.

// Always show the form...

// Retrieve the books information:
$q = "SELECT title, author, category, bookinfo FROM books WHERE user_id=$id";		
$r = @mysqli_query ($dbc, $q);

if (mysqli_num_rows($r) == 1) { // Valid user ID, show the form.

	// Get the user's information:
	$row = mysqli_fetch_array ($r, MYSQLI_NUM);
	
	// Create the form:
	echo '<form action="editbook.php" method="post">
<p>Title: <input type="text" name="title" size="15" maxlength="30" value="' . $row[0] . '" /></p>
<p>Author: <input type="text" name="author" size="15" maxlength="15" value="' . $row[1] . '" /></p>

<p><label for="category" value="' . $row[3] . '">Category:</label>

<select name="category" id="category">

 <option value="Fiction">Fiction</option>

 <option value="Novel">Novel</option>

 <option value="Narrative">Narrative</option>

 <option value="Non-Fiction">Non-Fiction</option>

 <option value="Mystery">Mystery</option>

 <option value="Science Fiction">Science Fiction</option>
 
 <option value="Hitorical">Hitorical</option>
 
 <option value="Horror">Horror</option>
 
 <option value="Thriller">Thriller</option>

 </select></p>


<p><input type="submit" name="submit" value="Submit" /></p>
<input type="hidden" name="id" value="' . $id . '" />
</form>';

} else { // Not a valid user ID.
	echo '<p class="error">This page has been accessed in error.</p>';
}

mysqli_close($dbc);
		
include ('includes/footer.html');
?>