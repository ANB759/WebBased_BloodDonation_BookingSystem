<?php 
// This script performs an INSERT query to add a record to the users table.

session_start(); // Access the existing session.
if (!isset($_SESSION['user_id'])) {  
}

$page_title = 'Register';
include ('includes/header.php');

// Check for form submission:
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$errors = array(); // Initialize an error array.
	
	// Check for a name:
	if (empty($_POST['name'])) {
		$errors[] = 'You forgot to enter your name.';
	} else {
		$n = trim($_POST['name']);
	}
	
	// Check for a  dob:
	if (empty($_POST['dob'])) {
		$errors[] = 'You forgot to enter your date of birth';
	} else {
		$dob = trim($_POST['dob']);
	}
	
	// Check for blood type:
	if (empty($_POST['bloodtype'])) {
		$errors[] = 'You forgot to select your blood type';
	} else {
		$bt = trim($_POST['bloodtype']);
	}
	
	// Check for phone no:
	if (empty($_POST['phone'])) {
		$errors[] = 'You forgot to enter your date of birth';
	} else {
		$ph = trim($_POST['phone']);
	}
	
	// Check for an email address:
	if (empty($_POST['email'])) {
		$errors[] = 'You forgot to enter your email address.';
	} else {
		$e = trim($_POST['email']);
	}

  	// Check for an address:
	if (empty($_POST['address'])) {
		$errors[] = 'You forgot to enter your address.';
	} else {
		$ad1 = trim($_POST['address']);
	}

  $ad2 = trim($_POST['address2']);

	// Check for gender:
    if (empty($_POST['gender'])) {
      $errors[] = 'You forgot to choose your gender.';
    } else {
      $g = trim($_POST['gender']);
    }
  
	
	// Check for a password:
	if (!empty($_POST['pass1'])) {
        if ($_POST['pass1'] != $_POST['pass2']) {
            $errors[] = 'Your password did not match the confirmed password.';
        } else {
            $p = trim($_POST['pass1']);
        }
    } else {
        $errors[] = 'You forgot to enter your password.';
    }	
	
	
	if (empty($errors)) { // If everything's OK. ($fn && $ln && $pn && $e)
	
		// Register the user in the database...
		
		require ('../mysqli_connect.php'); // Connect to the db.

		// Make the query:
		$q = "INSERT INTO users (name, dob, bloodtype, gender, phone, address, address2, email, password, registration_date) VALUES ('$n', '$dob', '$bt', '$g', '$ph', '$ad1', '$ad2', '$e', SHA1('$p'), NOW() )";		
		$r = mysqli_query ($dbc, $q); // Run the query.
		if ($r) { // If it ran OK.

			// Print a message:
			echo '<body>
      <section class="p-5 text-left mx-5">

        <h1 class="text-center mb-5 my-3 text-light">Register</h1>

        
        <div class="register-user wrapper text-left p-5" >
        <h1>Thank you!</h1>
        <p>You are now registered.</p>
        </div>
        </section>
      
      </body>';
		
		

		} else { // If it did not run OK.
	
			// Public message:
			echo '<body>
      <section class="p-5 text-left mx-5">

        <h1 class="text-center mb-5 my-3 text-light">Register</h1>
        <div class="register-user wrapper text-left p-5" >

        <h1>System Error</h1>
			<p class="error">You could not be registered due to a system error. We apologize for any inconvenience.</p>
      
      </div>
        </section>
      
      </body>';	
			// Debugging message:
			echo '<p>' . mysqli_error($dbc) . '<br /><br />Query: ' . $q . '</p>';
				
		} // End of if ($r) IF.
		
		mysqli_close($dbc); // Close the database connection.
		
		// Include the footer and quit the script:
		include ('includes/footer.html'); 
		exit();
		
	} else { // Report the errors.
	
		echo '<body>
      <section class="p-5 text-left mx-5">
        <h1 class="text-center mb-5 my-3 text-light">Register</h1>
        <div class="register-user wrapper text-left p-5" >
        <h1>Please try again below.</h1>
		  <p class="error">The following error(s) occurred:<br />';
		  foreach ($errors as $msg) { // Print each error.
			echo " - $msg<br />\n";
	  	}
		  echo '        
       </div>
        </section>
      
      </body>';
		
	} // End of if (empty($errors)) IF.

} // End of the main Submit conditional.
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
          rel="stylesheet" 
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
          crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

    
    <title>Register</title>
</head>
<body>
  
     <!--Navigation Bar-->
     <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
        <div class="container">
          <img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>

          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navmenu"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
  
          <div class="collapse navbar-collapse" id="navmenu">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                <a href="index.html" class="nav-link">Home</a>
              </li>              
              <li class="nav-item">
                <a href="login.php" class="nav-link">Login</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>  
      

      <!--register-->
      <section class="p-5 text-left mx-5 " >

        <h1 class="text-center mb-5 my-3">Register</h1>

        
        <div class="register-user text-left p-5" >
          <h3>Fillout this form</h3>
          <form action="register.php" method="POST">
            <!--Name-->
            <div class="col-20">
              <div class="mb-3">
                <label for="name" class="col-form-label">
                    Name:
                </label>
                <div class="textbox">
                  <input type="text" style="width: 500px" class="form-control form-width" 
				  placeholder="Name stated in your IC / Passport" name="name"
				  value="<?php if (isset($_POST['name'])) echo $_POST['name'];?>">
                 </div>
               </div>
            </div>

              <!--Date of birth as calendar-->
              <div class="col-20">
                <div class="mb-3">
                  <label for="date-birth" class="col-form-label" >
                      Date of birth:
                  </label>
                  <div class="textbox">
                    <input type="text" style="width: 250px"class="form-control form-width"
					placeholder="DD-MM-YYYY" name="dob"
					value="<?php if (isset($_POST['dob'])) echo $_POST['dob']; ?>">
                
                  </div>
                </div>
              </div>

              <!--bloodtype-->
              <div class="col-20">
                <div class="mb-3">
                  <label for="blood-type" class="col-form-label">
                      Blood type:
                  </label>
                  <?php 
	
					if (isset($_POST['bloodtype'])) echo $_POST['bloodtype'];
					// This script make apull-down menus for an HTML form: programmes.
					// Make the programme array.
					$bloodtype = array (1 =>'O Rh+', 'O Rh-', 'A Rh+','A Rh-', 'B Rh+','B Rh-', 'AB Rh+', 'AB Rh-');
					// Make the program pull-down menu.
				
					echo '<select name="bloodtype">';
					foreach ($bloodtype as $key=> $value) {
					echo "<option value=\"$value\">$value</option>\n";
					}
					echo '</select>';?>
                </div>
              </div>


              <!--Gender-->

              <div class="col-20">
                <div class="mb-3">
                  <label for="Gender" class="col-form-label">
                    Gender:
                  </label>
                  <?php if (isset($_POST['gender'])) echo $_POST['gender'];?>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="gender" value="m" checked>
                    <label class="form-check-label" for="flexRadioDefault1">
                      Male
                    </label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="gender" value="f">
                    <label class="form-check-label" for="flexRadioDefault2">
                      Female
                    </label>
                  </div>
                </div>
              </div>

              <!--Phone No.-->
              <div class="col-20">
                <div class="mb-3">
                  <label for="phone-no" class="col-form-label">
                      Phone. No:
                  </label>
                  <div class="textbox">
                    <input type="text" style="width: 250px"class="form-control form-width" placeholder="673-xxx-xxxx" 
					name="phone" value="<?php if (isset($_POST['phone'])) echo $_POST['phone']; ?>">
                
                  </div>
                </div>
              </div>

              <!--Address-->

              <div class="col-20">
                <div class="mb-3">
                  <label for="address" class="col-form-label">
                    Address:
                  </label>

                  <div class="textbox">
                    <input type="text" style="width: 500px" class="form-control form-width" 
					placeholder="Enter your address" name="address"
					value="<?php if (isset($_POST['address'])) echo $_POST['address']; ?>">
                
                  </div>

                  <div class="textbox">
                    <input type="text" style="width: 500px" class="form-control form-width" 
					placeholder="Enter your address" name="address2"
					value="<?php if (isset($_POST['address2'])) echo $_POST['address2']; ?>">
                
                  </div>
                </div>
              </div>
              <!--email-->
              <div class="col-20">
                <div class="mb-3">
                  <label for="email" class="col-form-label">
                      Email:
                  </label>
                  <div class="textbox">
                    <input type="email" style="width: 350px"class="form-control form-width" 
					placeholder="Enter your email" name="email"
					value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>">
                
                  </div>
                </div>
              </div>

              <!--passwords-->
            <div class="col-20">
              <div class="mb-3">
                <label for="password" class="col-form-label">
                    Password:
                </label>
                <div class="textbox">
                  <input type="password" style="width: 500px" class="form-control form-width" 
				  placeholder="Enter at least 8 characters" name="pass1"
				  value="<?php if (isset($_POST['pass1'])) echo $_POST['pass1']; ?>">
              
                </div>
              </div>
            </div>
            
            <div class="col-20">
              <div class="mb-3">
                <label for="confirm-pass" class="col-form-label">
                    Confirm Password:
                </label>
                <div class="textbox">
                  <input type="password" style="width: 500px" class="form-control form-width" 
				  placeholder="Must be the same from the 'Password'"name="pass2"
				  value="<?php if (isset($_POST['pass2'])) echo $_POST['pass2']; ?>">
              
                </div>
                </div>
            </div>
          </table>
            
          <div class="buttonsubmit text-center  ">
            <input type="submit" class="btn btn-primary" value="Register"></input>
          </div> 
          </form>
          

        </div>
      </section>


    <script src="jquery.datetimepicker.full.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    
</body>
</html>
<?php include ('includes/footer.html'); ?>