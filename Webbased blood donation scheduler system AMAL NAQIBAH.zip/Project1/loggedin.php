<?php # Script 12.9 - loggedin.php #2
// The user is redirected here from login.php.

session_start(); // Start the session.
$id = $_SESSION['user_id'];
echo $id;

// If no session value is present, redirect the user:
if (!isset($_SESSION['user_id'])) {

	// Need the functions:
	require ('includes/login_functions.inc.php');
	redirect_user();	

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
          rel="stylesheet" 
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
          crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

    
    
    
    <title>Profile</title>
</head>
<body>

    <!--Navigation Bar-->
    <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
        <div class="container">
          <img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>

          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navmenu"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
  
          <div class="collapse navbar-collapse" id="navmenu">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                <a href="setbooking.php" class="nav-link">Set Booking</a>
              </li>
              <li class="nav-item">
                <a href="psetting.php" class="nav-link">Profile Setting</a>
              </li>
              <li class="nav-item">
                <a href="logout.php" class="nav-link">Logout</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      <!--Show profile-->
    <section class="bg-dark text-light p-5 text-center text-sm-start">
        <div class="container">
            <div class="d-sm-flex align-items-center justify-content-between">
                <div>
                    <h2>Profile <span class="text-warning">User</span></h2>
                    <div class="table">
                        <table class="table table-dark table-striped table-dark">
                          
                            <thead>
                                <tr>
                                    <!--Header-->
                                 <th scope="col-2">User info</th>
                                 <th></th>
                                 <th scope="col"><a href="psetting.php" class="btn btn-success mt-1">Edit</a></th>
                                  
                                  
                                </tr>
                              </thead>
                              <tbody>
                                <tr> 
                                    <!--Row 1-->
                                  <th scope="row">Name:</th>
                                  <td ><?php echo "{$_SESSION['name']}" ?></td>
                                  <td></td>
                                </tr>
                                <tr> 
                                    <!--Row 2-->
                                  <th scope="row">Date of Birth:</th>
                                  <td ><?php echo" {$_SESSION['dob']}" ?></td>
                                  <td></td>
                                </tr>
                                <tr> 
                                    <!--Row 3-->
                                  <th scope="row">Blood Type:</th>
                                  <td ><?php echo" {$_SESSION['bloodtype']}" ?></td>
                                  <td></td>
                                </tr>
                                <tr> 
                                    <!--Row 4-->
                                  <th scope="row">Phone No. :</th>
                                  <td >+<?php echo" {$_SESSION['phone']}" ?></td>
                                  <td></td>
                                </tr>
                                <tr> 
                                    <!--Row 5-->
                                  <th scope="row">Email:</th>
                                  <td ><?php echo" {$_SESSION['email']}" ?></td>
                                  <td></td>
                                </tr>
                          </table>
                    </div>
                </div>
                <img class="img-fluid w-60 d-none d-sm-block" 
                src="img/bloodlogo4.png" alt="">
                
            </div>
        </div>
    </section>

    <!--booking-->

    <?php 

    require ('../mysqli_connect.php');
    $q = "SELECT * FROM schedule WHERE user_id=".$_SESSION['user_id'];
    $r= @mysqli_query ($dbc, $q);

    //Count number of bookings

    $num = mysqli_num_rows ($r);

    if ($num > 0) {

      //if booking present

      echo '<section class="p-5">
      
          <div class="align-items-center justify-content-between">
          <div class="table">
              <table class="table table-dark table-striped">
                
                  <thead>
                      <tr>
                          <!--Row 1-->
                        <th scope="col">Donation period</th>
                        <th scope="col">Location</th>
                        <th scope="col">Date</th>
                        <th scope="col">Month</th>
                        <th scope="col">Year</th>
                        <th><a href="setbooking.php" class="btn btn-success mt-1">Set new booking</a></th>
                
                      </tr>
                    </thead>';

                      while ($row = mysqli_fetch_array ($r, MYSQLI_ASSOC)){

                        echo '<tbody>
                        <tr> 
                            <!--Row 2-->
                          <th scope="row">' . $row ['time_p'] . ' </th>
                          <td scope="row">' . $row ['h_name'] . '</td>
                          <td scope="row">' . $row ['dd'] . '</td>
                          <td scope="row">' . $row ['mm'] . '</td>
                          <td scope="row">' . $row ['yyyy'] . '</td>
                          <td></td>
                          
                        </tr>';
                      }
                      echo '</table>';
                      mysqli_free_result ($r);

      
    } else {
      //if booking is empty

      echo '<section class="p-5">
      
          <div class="align-items-center justify-content-between">
          <div class="table">
              <table class="table table-dark table-striped">
                
                  <thead>
                      <tr>
                          <!--Row 1-->
                        <th scope="col">Donation period</th>
                        <th scope="col">Location</th>
                        <th scope="col">Date</th>
                        <th scope="col">Month</th>
                        <th scope="col">Year</th>
                        <th><button class="btn btn-success">Set booking</button></th>
                
                      </tr>
                    </thead>
                    <tbody>
                      <tr> 
                          <!--Row 2-->
                        <th scope="row" colspan="6">There are no available bookings.</th>
                        
                      </tr>
                      
                      </table>
          </div>
          </div>
      </div>
  </section>';
    }

    mysqli_close($dbc);
     
    ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>
</html>
<?php include ('includes/footer.html'); ?>