<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head">
	<title><?php echo $page_title; ?></title>	
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
          rel="stylesheet" 
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
          crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">


</head>
<body>
	
	 <!--Navigation Bar-->
	 <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
		<div class="container">
		  <img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>
  
		  <button
			class="navbar-toggler"
			type="button"
			data-bs-toggle="collapse"
			data-bs-target="#navmenu"
		  >
			<span class="navbar-toggler-icon"></span>
		  </button>
  
		  <div class="collapse navbar-collapse" id="navmenu">
			<ul class="navbar-nav ms-auto">
				
					<li class="nav-item">
					<a href="index.html" class="nav-link">Home</a>
				  </li>
			  <li class="nav-item">
				<a href="register.php" class="nav-link">Register</a>
			  </li>
			  <li class="nav-item">
				<a href="login.php" class="nav-link">Login</a>
			  </li>
			</ul>
		  </div>
		</div>
	  </nav>
  
	<script src="jquery.datetimepicker.full.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
   
	<div id="content"><!-- Start of the page-specific content. -->
<!-- Script 12.10 - header.html -->