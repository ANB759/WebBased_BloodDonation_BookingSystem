<?php 
// This script performs an INSERT query to add a record to the users table.

session_start(); // Access the existing session.

if (!isset($_SESSION['user_id'])) {  
}

$page_title = 'Book An Appointment';



// Check for form submission:
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$errors = array(); // Initialize an error array.
	// add errors for list check 
	
	// Check for hospital:
	if (empty($_POST['h_name'])) {
		$errors[] = 'You forgot to choose the location.';
	} else {
		$hn = trim($_POST['h_name']);
	}
	
	// Check for time:
	if (empty($_POST['time_p'])) {
		$errors[] = 'You forgot to choose donation time.';
	} else {
		$t = trim($_POST['time_p']);
	}
	
	// Check for a dd:
	if (empty($_POST['dd'])) {
		$errors[] = 'You forgot to set the date.';
	} else {
		$da = trim($_POST['dd']);
	}
	
	// Check for a mm:
	if (empty($_POST['mm'])) {
		$errors[] = 'You forgot to set the month.';
	} else {
		$mo = trim($_POST['mm']);
	}
	
	// Check for a yyyy:
	if (empty($_POST['yyyy'])) {
		$errors[] = 'You forgot to set the year.';
	} else {
		$ye = trim($_POST['yyyy']);
	}

	// Check for weight:
	if (empty($_POST['weight'])) {
		$errors[] = 'You forgot to enter your weight.';
	} else {
		$wght = trim($_POST['weight']);
	}
	// Check for donated blood:
	if (empty($_POST['donatedblood'])) {
		$errors[] = 'You forgot to choose yes or no.';
	} else {
		$donb = trim($_POST['donatedblood']);
	}
	
	//phys
	$phys = (isset($_POST['physical_add'])) ? $_POST['physical_add'] : array();
	if (count($phys)>0){
		foreach($phys as $pp){
			echo $pp . ' ';
		}
	} else {
		$errors[] = "No options have been selected on Q1";
	}
	$health = (isset($_POST['suffer_health'])) ? $_POST['suffer_health'] : array();
	if (count($health)>0){
		foreach($health as $hlth){
			echo $hlth . ' ';
		}
	} else {
		$errors[] = "No options have been selected on Q2";
	}
	$intake = (isset($_POST['intakes'])) ? $_POST['intakes'] : array();
	if (count($intake)>0){
		foreach($intake as $in){
			echo $in . ' ';
		}
	} else {
		$errors[] = "No options have been selected on Q3";
	}
	$transfusion = (isset($_POST['transfusion'])) ? $_POST['transfusion'] : array();
	if (count($transfusion)>0){
		foreach($transfusion as $tt){
			echo $tt . ' ';
		}
	} else {
		$errors[] = "No options have been selected on Q4";
	}
	//add if no errors list check 
	
	if (empty($errors)) { // If everything's OK. ($fn && $ln && $pn && $e)
	
		// Register the user in the database...
		
		require ('../mysqli_connect.php'); // Connect to the db.
		$id = $_SESSION['user_id'];
		echo $id;
		
		// Make the query:
		$q = "INSERT INTO schedule (user_id,h_name, time_p, dd, mm, yyyy, weight, donatedblood, physical_add, suffer_health, intakes,transfusion) VALUES ('$id','$hn', '$t', '$da', '$mo', '$ye', '$wght', '$donb', '$pp', '$hlth', '$in', '$tt')";		

		$r = mysqli_query ($dbc, $q); // Run the query.
		if ($r) { // If it ran OK.

			// Print a message:
			echo '<!DOCTYPE html>
			<html lang="en">
			<head>
				<meta charset="UTF-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<meta name="viewport" content="width=device-width, initial-scale=1.0">
				<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
					  rel="stylesheet" 
					  integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
					  crossorigin="anonymous">
				<link rel="stylesheet" href="style.css">
				<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
			
				<title>Book Schedule</title>
			</head>
			<body>
				 <!--Navigation Bar-->
				 <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
				<div class="container">
					<img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>
			
				  <button
					class="navbar-toggler"
					type="button"
					data-bs-toggle="collapse"
					data-bs-target="#navmenu"
				  >
					<span class="navbar-toggler-icon"></span>
				  </button>
			
				  <div class="collapse navbar-collapse" id="navmenu">
					<ul class="navbar-nav ms-auto">
						<li class="nav-item">
							<a href="loggedin.php" class="nav-link">Home</a>
						  </li>
						<li class="nav-item">
						<a href="psetting.php" class="nav-link">Profile Setting</a>
					  </li>
					  <li class="nav-item">
						<a href="logout.php" class="nav-link">Logout</a>
					  </li>
					</ul>
				  </div>
				</div>
			  </nav> 
			
			<section class="p-5 text-left mx-5">
			  <h1 class="text-center mb-5 my-3">Register</h1>
			  <div class="register-user text-left p-5" >
			  
			  <p></p><p><h1>Thank you!</h1></p>
		<p>You have booked an appointment.</p>
		<a href="loggedin.php" class="nav-link">Return to main page</a>
		</div>		
        </section>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

      </body>';		

		} else { // If it did not run OK.
	
			// Public message:
			echo '<!DOCTYPE html>
			<html lang="en">
			<head>
				<meta charset="UTF-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<meta name="viewport" content="width=device-width, initial-scale=1.0">
				<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
					  rel="stylesheet" 
					  integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
					  crossorigin="anonymous">
				<link rel="stylesheet" href="style.css">
				<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
			
				<title>Book Schedule</title>
			</head>
			<body>
				 <!--Navigation Bar-->
				 <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
				<div class="container">
					<img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>
			
				  <button
					class="navbar-toggler"
					type="button"
					data-bs-toggle="collapse"
					data-bs-target="#navmenu"
				  >
					<span class="navbar-toggler-icon"></span>
				  </button>
			
				  <div class="collapse navbar-collapse" id="navmenu">
					<ul class="navbar-nav ms-auto">
						<li class="nav-item">
							<a href="loggedin.php" class="nav-link">Home</a>
						  </li>
						<li class="nav-item">
						<a href="psetting.php" class="nav-link">Profile Setting</a>
					  </li>
					  <li class="nav-item">
						<a href="logout.php" class="nav-link">Logout</a>
					  </li>
					</ul>
				  </div>
				</div>
			  </nav> 
			  
			  <section class="p-5 text-left mx-5">
			   <h1 class="text-center mb-5 my-3">System Error</h1>
			   <div class="register-user text-left p-5" >
			<p class="error">You could not be booked due to a system error. We apologize for any inconvenience.</p>
			
			</div>		
        </section>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

      </body>'; 
	
			// Debugging message:
			echo '<p>' . mysqli_error($dbc) . '<br /><br />Query: ' . $q . '</p>';
				
		} // End of if ($r) IF.
		
		mysqli_close($dbc); // Close the database connection.
		
		// Include the footer and quit the script:
		include ('includes/footer.html'); 
		exit();
		
	} else { // Report the errors.
	
		echo '<!DOCTYPE html>
		<html lang="en">
		<head>
			<meta charset="UTF-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
				  rel="stylesheet" 
				  integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
				  crossorigin="anonymous">
			<link rel="stylesheet" href="style.css">
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
		
			<title>Book Schedule</title>
		</head>
		<body>
			 <!--Navigation Bar-->
			 <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
			<div class="container">
				<img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>
		
			  <button
				class="navbar-toggler"
				type="button"
				data-bs-toggle="collapse"
				data-bs-target="#navmenu"
			  >
				<span class="navbar-toggler-icon"></span>
			  </button>
		
			  <div class="collapse navbar-collapse" id="navmenu">
				<ul class="navbar-nav ms-auto">
					<li class="nav-item">
						<a href="loggedin.php" class="nav-link">Home</a>
					  </li>
					<li class="nav-item">
					<a href="psetting.php" class="nav-link">Profile Setting</a>
				  </li>
				  <li class="nav-item">
					<a href="logout.php" class="nav-link">Logout</a>
				  </li>
				</ul>
			  </div>
			</div>
		  </nav> 
      <section class="p-5 text-left mx-5">
        <h1 class="text-center mb-5 my-3t">Set booking</h1>
        <div class="register-user text-left p-5" >
        <h1>Please try again below</h1>
		  <p class="error">The following error(s) occurred:<br />';
		  foreach ($errors as $msg) { // Print each error.
			echo " - $msg<br />\n";
	  	}
		  echo '</p><p>We apologise for any inconvenience occured.</p><p><br /></p>
        
       </div>
        </section>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

      </body>';
		
	} // End of if (empty($errors)) IF.

} // End of the main Submit conditional.
	
?>


	<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
          rel="stylesheet" 
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
          crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

    <title>Book Schedule</title>
</head>
<body>
	 <!--Navigation Bar-->
	 <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
    <div class="container">
        <img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>

      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navmenu"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navmenu">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a href="loggedin.php" class="nav-link">Home</a>
              </li>
            <li class="nav-item">
            <a href="psetting.php" class="nav-link">Profile Setting</a>
          </li>
          <li class="nav-item">
            <a href="logout.php" class="nav-link">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav> 

		<form action="setbooking.php" method="post">
          <!--Schedule Bookings-->
          <section class="p-5 text-left mx-5">
            <div class="set-booking text-left p-5">
              <h1>Schedule a booking</h1>
              <div class="form align-center">


                <div class="col-20">
                  <div class="mb-3">
                    <label for="hospital" class="col-form-label">
                        Hospital:
                    </label>
                    <?php 
	
						if (isset($_POST['h_name'])) echo $_POST['h_name'];
						// This script make apull-down menus for an HTML form: programmes.
						// Make the programme array.
						$h_name = array (1 =>'RIPAS Hospital', 'SSB hospital', 'PIHM Hospital', 'PMMPMHAB Hospital');
						// Make the program pull-down menu.
					
						echo '<select name="h_name">';
						foreach ($h_name as $key=> $value) {
						echo "<option value=\"$value\">$value</option>\n";
						}
						echo '</select>';
					?>
                  </div>
                </div>

                <div class="col-20">
                  <div class="mb-3">
                    <label for="time-period" class="col-form-label">
                        Time Period:
                    </label>
                    <?php 
	
						if (isset($_POST['time_p'])) echo $_POST['time_p'];
						// This script make apull-down menus for an HTML form: bookingtime.
						// Make the programme array.
						$time = array (1 =>'8:00-9:00', '10:00-11:00', '1:00-2:00', '3:00-4:00');
						// Make the bookingtime pull-down menu.
					
						echo '<select name="time_p">';
						foreach ($time as $key=> $value) {
						echo "<option value=\"$value\">$value</option>\n";
						}
						echo '</select>';?>
                  </div>
                </div>

                <div class="col-20">
                  <div class="mb-3">
                    <label for="Date" class="col-form-label" >
                        Date:
                    </label>
                    <?php 
	
						if (isset($_POST['dd'])) echo $_POST['dd'];
						// This script make apull-down menus for an HTML form: bookingdate.
						// Make the day-for date array.
						$dd = array (1 =>'03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23',
						'24', '25', '26', '27', '28', '29', '30', '31');
						// Make the day-date pull-down menu.
					
						echo '<select name="dd">';
						foreach ($dd as $key=> $value) {
						echo "<option value=\"$value\">$value</option>\n";
						}
						echo '</select>';?> 
						
						<?php 
						
						if (isset($_POST['mm'])) echo $_POST['mm'];
						// This script make apull-down menus for an HTML form: bookingmonth.
						// Make the month array.
						$mm = array (1 =>'June', 'July', 'Sept', 'Oct', 'Nov', 'Dec');
						// Make the month pull-down menu.
					
						echo '<select name="mm">';
						foreach ($mm as $key=> $value) {
						echo "<option value=\"$value\">$value</option>\n";
						}
						echo '</select>';?>

						<?php 
						
						if (isset($_POST['yyyy'])) echo $_POST['yyyy'];
						// This script make apull-down menus for an HTML form: bookingyear.
						// Make the year array.
						$yyyy = array (1 =>'2022');
						// Make the month pull-down menu.
					
						echo '<select name="yyyy">';
						foreach ($yyyy as $key=> $value) {
						echo "<option value=\"$value\">$value</option>\n";
						}
						echo '</select>';?>
                  </div>
                </div>

				<!--Weight-->
				<div class="col-20">
              <div class="mb-3">
                <label for="weight" class="col-form-label">
                    Weight (in Kg):
                </label>
                <div class="textbox">
                  <input style="width: 200px" placeholder="example: 78.0" type="text" class="form-control form-width" 
				  placeholder="State your current weight" name="weight"
				  value="<?php if (isset($_POST['weight'])) echo $_POST['weight'];?>">
                 </div>
               </div>

						<!--Donated?-->

			<div class="col-20">
                <div class="mb-3">
                  <label for="donatedblood" class="col-form-label">
                   <b> Have you donated blood recently? (1 month prior)</b>
                  </label>
                  <?php if (isset($_POST['donatedblood'])) echo $_POST['donatedblood'];?>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="donatedblood" value="y" checked>
                    <label class="form-check-label" for="flexRadioDefault1">
                      Yes
                    </label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="donatedblood" value="n">
                    <label class="form-check-label" for="flexRadioDefault2">
                      No
                    </label>
                  </div>
                </div>
              </div>

				<!--physical check-->

				<label for="phys" class="col-form-label">
						<b>Q1. In the last six months have you had any of the following?</b> 
							<p><span class="text-danger">*Tick if any</span></p>
					</label>

				<div class="form-check">
					<input class="form-check-input" name="physical_add[]" type="checkbox" value="tattooing" id="flexCheckDefault">
					<label class="form-check-label" for="flexCheckDefault">
					None
					</label>
					
				</div>
				<div class="form-check">
					<input class="form-check-input" name="physical_add[]" type="checkbox" value="tattooing" id="flexCheckDefault">
					<label class="form-check-label" for="flexCheckDefault">
					Tattooing
					</label>
					
				</div>
				<div class="form-check">
					<input class="form-check-input" name="physical_add[]" type="checkbox" value="piercing" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
						Ear piercing
					</label>
				</div>
				<div class="form-check">
					<input class="form-check-input" name="physical_add[]" type="checkbox" value="dental-extraction" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
						Dental extraction
					</label>
				</div>

				<!--Health check-->

				<label for="Gender" class="col-form-label text-b"><b>
						Q2. Do you suffer from of have suffered from any of the following?
					</b>
					<p><span class="text-danger">*Tick if any</span></p></label>
				<!--0--><div class="form-check">
					<input class="form-check-input" name="suffer_health[]" type="checkbox" value="heart-disease" id="flexCheckDefault">
					<label class="form-check-label" for="flexCheckDefault">
					None
					</label>
				</div>
				<!--1--><div class="form-check">
					<input class="form-check-input" name="suffer_health[]" type="checkbox" value="heart-disease" id="flexCheckDefault">
					<label class="form-check-label" for="flexCheckDefault">
					Heart disease
					</label>
				</div>
				<!--2--><div class="form-check">
					<input class="form-check-input" name="suffer_health[]" type="checkbox" value="cancer" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Cancer/Malignant Disease
					</label>
				</div>
				<!--3--><div class="form-check">
					<input class="form-check-input" name="suffer_health[]" type="checkbox" value="diabetes" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Diabetes
					</label>
				</div>
				<!--4--><div class="form-check">
					<input class="form-check-input" name="suffer_health[]" type="checkbox" value="hepatitisB/C" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Hepatitis B/C
					</label>
				</div>
				<!--5--><div class="form-check">
					<input class="form-check-input" name="suffer_health[]" type="checkbox" value="STD" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Sexually Transmitted Disease
					</label>
				</div>
				<!--6--><div class="form-check">
					<input class="form-check-input" name="suffer_health[]" type="checkbox" value="typhoid" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Typhoid (Lasts one year)
					</label>
				</div>
				<!--7--><div class="form-check">
					<input class="form-check-input" name="suffer_health[]" type="checkbox" value="lung-disease" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Lung disease
					</label>
				</div>
				<!--8--><div class="form-check">
					<input class="form-check-input" name="suffer_health[]" type="checkbox" value="tubercolosis" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Tubercolosis
					</label>
				</div>
				<!--9--><div class="form-check">
					<input class="form-check-input" type="checkbox" name="suffer_health[]" value="allergy" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Allergy
					</label>
				</div>
				<!--10--><div class="form-check">
					<input class="form-check-input" type="checkbox" name="suffer_health[]" value="kidney-disease" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Kidney disease
					</label>
				</div>
				<!--11--><div class="form-check">
					<input class="form-check-input" type="checkbox" name="suffer_health[]" value="epilepsy" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Epilepsy 
					</label>
				</div>
				<!--12--><div class="form-check">
					<input class="form-check-input" type="checkbox" name="suffer_health[]" value="abn.bleeding" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Abnormal bleeding tendency
					</label>
				</div>
				<!--13--><div class="form-check">
					<input class="form-check-input" type="checkbox" name="suffer_health[]" value="jaundice" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Jaundice (Lasts one year)
					</label>
				</div>
				<!--14--><div class="form-check">
					<input class="form-check-input" type="checkbox" name="suffer_health[]" value="malaria" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Malaria (Past 6 months)
					</label>
				</div>
				<!--15--><div class="form-check">
					<input class="form-check-input" type="checkbox" name="suffer_health[]" value="fainting-spells" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Fainting spells
					</label>
				</div>

				<div class="meds">


					<!--intakes-->

				<label for="Gender" class="col-form-label"><b>
						Q3. Have you taken any of the following in the past 72 Hours?
					</b>
					<p><span class="text-danger">*Tick if any</span></p></label>
				<!--0--><div class="form-check">
					<input class="form-check-input" type="checkbox" value="antibiotics" name="intakes[]" id="flexCheckDefault">
					<label class="form-check-label" for="flexCheckDefault">
					None
					</label>
				</div>
				<!--1--><div class="form-check">
					<input class="form-check-input" type="checkbox" value="antibiotics" name="intakes[]" id="flexCheckDefault">
					<label class="form-check-label" for="flexCheckDefault">
					Antibiotics
					</label>
				</div>
				<!--2--><div class="form-check">
					<input class="form-check-input" type="checkbox" value="steroids" name="intakes[]" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Steroids
					</label>
				</div>
				<!--3--><div class="form-check">
					<input class="form-check-input" type="checkbox" value="aspirin" name="intakes[]" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Aspirin
					</label>
				</div>
				<!--4--><div class="form-check">
					<input class="form-check-input" type="checkbox" value="vaccinations" name="intakes[]" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Vaccinations
					</label>
				</div>
				<!--5--><div class="form-check">
					<input class="form-check-input" type="checkbox" value="alcohol" name="intakes[]" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Alcohol
					</label>
				</div>
				<!--6--><div class="form-check">
					<input class="form-check-input" type="checkbox" value="rabies-vac" name="intakes[]" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Dog bite Rabies Vaccine (1 year)
					</label>
				</div>

				<!--transfusion checkk-->

				<label for="Gender" class="col-form-label"><b>
						Q4. Is there any history of surgery of blood transfusion in the past six months?
					</b>
					<p><span class="text-danger">*Tick if any</span></p></label>
				<!--0--><div class="form-check">
					<input class="form-check-input" type="checkbox" value="major" name="transfusion[]" id="flexCheckDefault">
					<label class="form-check-label" for="flexCheckDefault">
					None
					</label>
				</div>
				<!--1--><div class="form-check">
					<input class="form-check-input" type="checkbox" value="major" name="transfusion[]" id="flexCheckDefault">
					<label class="form-check-label" for="flexCheckDefault">
					Major
					</label>
				</div>
				<!--2--><div class="form-check">
					<input class="form-check-input" type="checkbox" value="Minor" name="transfusion[]" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Minor
					</label>
				</div>
				<!--3--><div class="form-check">
					<input class="form-check-input" type="checkbox" value="blood-transfusion" name="transfusion[]" id="flexCheckChecked">
					<label class="form-check-label" for="flexCheckChecked">
					Blood transfusion
					</label>
				</div>
				</div>

            </div>

			

              </div>
			  <div class="bttn-submit text-center my-5">
			
			  <input type="submit" name="submit" class="btn btn-primary" value="Set Booking" />
            
			  </div>
              </div>
		</form>
          </section>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>
</html>

<?php include ('includes/footer.html'); ?>