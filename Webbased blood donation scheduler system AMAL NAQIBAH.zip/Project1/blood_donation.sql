-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2022 at 07:18 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blood_donation`
--

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `hos_id` int(11) NOT NULL,
  `h_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hos_id`, `h_name`) VALUES
(4, 'PHIM Hospital'),
(2, 'PMMPMHAB Hospital'),
(1, 'RIPAS Hospital'),
(3, 'SSB Hospital');

-- --------------------------------------------------------

--
-- Table structure for table `pwdreset`
--

CREATE TABLE `pwdreset` (
  `pwdResetId` int(11) NOT NULL,
  `pwdResetEmail` text NOT NULL,
  `pwdResetSelector` text NOT NULL,
  `pwdResetToken` longtext NOT NULL,
  `pwdResetExpires` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `user_id` int(10) NOT NULL,
  `s_id` int(11) NOT NULL,
  `h_name` varchar(20) NOT NULL,
  `time_p` varchar(20) NOT NULL,
  `dd` varchar(20) NOT NULL,
  `mm` varchar(20) NOT NULL,
  `yyyy` varchar(20) NOT NULL,
  `status` varchar(100) NOT NULL,
  `weight` int(4) NOT NULL,
  `donatedblood` varchar(1) NOT NULL,
  `physical_add` varchar(400) NOT NULL,
  `suffer_health` varchar(400) NOT NULL,
  `intakes` varchar(400) NOT NULL,
  `transfusion` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`user_id`, `s_id`, `h_name`, `time_p`, `dd`, `mm`, `yyyy`, `status`, `weight`, `donatedblood`, `physical_add`, `suffer_health`, `intakes`, `transfusion`) VALUES
(20, 14, 'RIPAS Hospital', '8:00-9:00', '01', 'May', '2022', '', 50, 'n', '0', '0', '0', '0'),
(18, 17, 'RIPAS Hospital', '8:00-9:00', '25', 'May', '2022', '', 76, 'n', '0', '0', '0', '0'),
(15, 23, 'SSB Hospital', '10:00-11:00', '02', 'June', '2022', '', 83, 'n', '0', '0', '0', '0'),
(16, 27, 'PIHM Hospital', '8:00-9:00', '01', 'June', '2022', '', 87, 'n', '0', '0', '0', '0'),
(19, 43, 'RIPAS Hospital', '8:00-9:00', '03', 'June', '2022', '', 67, 'n', 'tattooing', 'heart-disease', 'antibiotics', 'major');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` int(11) NOT NULL,
  `hos_id` int(11) NOT NULL,
  `s_name` varchar(200) NOT NULL,
  `s_dob` varchar(20) NOT NULL,
  `s_phone` varchar(20) NOT NULL,
  `s_address` varchar(250) NOT NULL,
  `s_email` varchar(200) NOT NULL,
  `s_password` varchar(20) NOT NULL,
  `usertype` varchar(50) NOT NULL DEFAULT 'admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `hos_id`, `s_name`, `s_dob`, `s_phone`, `s_address`, `s_email`, `s_password`, `usertype`) VALUES
(1, 1, 'Shahril bin Sani', '09-10-1985', '6732297564', 'No.24, jalan sengkuriong A, sengkurong, Brunei', 'Shahril.Sani@S.bloodbank.bn', 'shahrilsani', 'admin'),
(2, 2, 'Amirah binti Osman', '10-07-1973', '6732895736', 'No. 34, jalan sengkarai A, Tutong', 'Amirah.Osman@s.bloodbank.bn', 'amirahosman', 'admin'),
(5, 2, 'Amamiya Kuri', '01/01/1989', '4475682', 'No.15, Jalan Bintang, Simpang 445, Kampung Lamunin, Tutong', 'kuri.amamiya@s.bloodbank.bn', 'amamiyakuri', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `dob` text NOT NULL,
  `bloodtype` varchar(10) NOT NULL,
  `gender` char(1) NOT NULL,
  `phone` text NOT NULL,
  `address` varchar(100) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(20) NOT NULL,
  `registration_date` date NOT NULL,
  `usertype` varchar(50) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `dob`, `bloodtype`, `gender`, `phone`, `address`, `address2`, `email`, `password`, `registration_date`, `usertype`) VALUES
(16, 'Saiful bahri bin Haji Tujoh', '16-11-1984', 'A Rh-', 'm', '6732255394', 'no.43, jalan bukit sulang, lamunin, tutong', '-', 'bahri7@gmail.com', '7af25dce08a3f22ce75f', '2022-05-16', 'user'),
(17, 'Shahril bin bintang', '13-03-1997', 'AB Rh+', 'm', '6735546856', 'No.15, simpang 366, Kampung bangnukat, tutong', '-', 'shahril4@gmail.com', '8da62593fb0a80d2f92e', '2022-05-16', 'user'),
(18, 'Khairul bin Ahmad', '09-08-1985', 'B Rh-', 'm', '6735546852', 'no.65, kampung kiudang, tutong', '-', 'Khairul1@gmail.com', '806ddd10d812b8b6d29d', '2022-05-16', 'user'),
(19, 'Bahrin bin Haji Tujoh', '16-07-1978', 'O Rh+', 'm', '6738804694', 'No.25. 225 simpang tembikai, limaumanis, brunei', '-', 'bahrin7@gmail.com', '664568b99b33d30bbe1d', '2022-05-20', 'user'),
(20, 'Nursahirah binti roslan', '24-04-1999', 'A Rh+', 'f', '6732245638', 'Simpang 43, No.12, kampung sengkarai, tutong', '-', 'sahirah24@gmail.com', '0982a6cd953f8a4c7eed', '2022-05-20', 'user'),
(22, 'Nurazirah binti Ismail', '15-06-1998', 'A Rh+', 'f', '6735548961', 'no.34 simpang Tuah, Lamunin, Tutong', '-', 'nurazirah156@gmail.com', '5ae729ab1846ce4486e2', '2022-05-27', 'user'),
(23, 'Malius Cage', '30-06-1978', 'B Rh-', 'm', '6732876453', 'No.22, Jalan beruang, bukit beruang,tutong', '-', 'cage123@gmail.com', '7b7c5ce3f6b19bedc8d6', '2022-06-03', 'user'),
(25, 'Amal Naqibah binti Bahrin', '07-05-1998', 'O Rh+', 'f', '6738804694', 'no.17, jalan Bintudoh, Kg bintudoh, lamunin, tutong', '-', 'amalnaqibahb7@gmail.com', 'cfec0b9945fae9d56d11', '2022-06-03', 'user'),
(26, 'kamoshida yuu', '09-07-2000', 'O Rh+', 'm', '6737785461', 'Simpang 77, Jalan semaun. No.23, Kiudang, Tutong', '-', 'kamoshidayuu@gmail.com', '04750f8bc26d589e02dd', '2022-06-03', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`hos_id`),
  ADD UNIQUE KEY `h_name` (`h_name`);

--
-- Indexes for table `pwdreset`
--
ALTER TABLE `pwdreset`
  ADD PRIMARY KEY (`pwdResetId`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`s_id`),
  ADD UNIQUE KEY `user_id_3` (`user_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `h_name` (`h_name`),
  ADD KEY `user_id_2` (`user_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`),
  ADD KEY `hos_id` (`hos_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hospital`
--
ALTER TABLE `hospital`
  MODIFY `hos_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pwdreset`
--
ALTER TABLE `pwdreset`
  MODIFY `pwdResetId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`hos_id`) REFERENCES `hospital` (`hos_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
