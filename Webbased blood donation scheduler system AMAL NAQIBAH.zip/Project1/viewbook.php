<?php 

session_start(); // Access the existing session.
if (!isset($_SESSION['user_id'])) {
	require('includes/login_functions.inc.php');
        redirect_user();
}

// This script retrieves all the records from the users table.
// This new version links to edit and delete pages.


$page_title = 'View the Current Schedules';
include ('includes/header.html');
echo '<p></p><p><h1>Donation schedule</h1></p>';

require ('../mysqli_connect.php');
		
// Define the query:

$q = "SELECT h_name, time, dd, mm, yyyy AS hospital, time, dd,mm,yyyy FROM schedule";		
$r = @mysqli_query ($dbc, $q);

// Count the number of returned rows:
$num = mysqli_num_rows($r);

if ($num > 0) { // If it ran OK, display the records.

	// Print how many user bookings there are:
	echo "<p>Here are your book schedules.</p>\n";

	// Table header:
	echo '<style>
				
				table,td {
				margin-top: 20px;
				 
				  border: 2px solid black;
				 
				}
				td{
					height: 100%;
				  }
				tr:nth-child(even) {background-color: #f0000;
				}
					tr:nth-child(odd) {background-color: #f0000;}
         </style>
	<table style="border:2px solid black" align="center" >
	<tr>
		<td align="center"><b>Edit</b></td>
		<td align="center"><b>Delete</b></td>
		<td align="center"><b>hospital</b></td>
		<td align="center"><b>Day</b></td>
		<td align="center"><b>Month</b></td>
		<td align="center"><b>Year</b></td>
		<td align="center"><b>Time</b></td>
		
	</tr>
';
	
	// Fetch and print all the records:
	while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)) {
		echo '<tr>
			<td align="center"> Edit</a></td>
			<td align="center"> Delete</a></td>
			<td align="center">' . $row['h_name'] . '</td>
			<td align="center">' . $row['dd'].'</td>
			<td align="center">' . $row['mm'].'</td>
			<td align="center">' . $row['yyyy'].'</td>
			<td align="center">' . $row['time'] . '</td>
		</tr>
		';
	}

	echo '</table>';
	mysqli_free_result ($r);	

	

} else { // If no records were returned.
	echo '<p class="error">There are currently no booking scheduled.</p>';
}

mysqli_close($dbc);

include ('includes/footer.html');
?>