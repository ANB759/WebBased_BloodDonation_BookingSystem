<?php # Script 12.9 - loggedin.php #2
// The user is redirected here from login.php.

session_start(); // Start the session.

// If no session value is present, redirect the user:
if (!isset($_SESSION['user_id'])) {

	// Need the functions:
	require ('includes/login_functions.inc.php');
	redirect_user();	

}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
    rel="stylesheet" 
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" 
    crossorigin="anonymous">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

   
   
    <title>Profile setting</title>
</head>
<body>
   <!--Navigation Bar-->
   <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 fixed-top">
    <div class="container">
        <img src="img/bloodIcon2.png" alt=""><a href="#" class="navbar-brand">Blood Bank Brunei <span class="text-warning text-sm">Donate to save a life</span></a>

      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navmenu"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navmenu">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a href="loggedin.php" class="nav-link">Home</a>
              </li>
            <li class="nav-item">
            <a href="setbooking.php" class="nav-link">Set Booking</a>
          </li>
          <li class="nav-item">
            <a href="logout.php" class="nav-link">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav> 

  <?php
  require ('mysqli_connect.php');
  $q = "SELECT * FROM users WHERE user_id=".$_SESSION['user_id'];
    $r= @mysqli_query ($dbc, $q);
while ($row =mysqli_fetch_array($r, MYSQLI_ASSOC)){
        //<!--Setting's form-->

     echo '<section class="p-5 text-center text-sm-start">
        <div class="container">
            <div class="d-sm-flex align-items-center justify-content-between">
                <div>
                  <form action="editinfo.php" method="POST">
                    <h2>Profile <span class="text-warning">User</span></h2>
                    <div class="table">
                        <table class="table table-light table-striped table-light">
                          
                            <thead>
                                <tr>
                                    <!--Header-->
                                 <th scope="col-2">User info</th>
                                 <th></th>
                                 <th scope="col"></th>
                                  
                                  
                                </tr>
                              </thead>
                              <tbody>
                                <tr> 
                                    <!--Row 1-->
                                  <th scope="row">Name:</th>
                                  <td >'.$row['name'].'</td>
                                  <td></td>
                                </tr>
                                <tr> 
                                    <!--Row 2-->
                                  <th scope="row">Date of Birth:</th>
                                  <td >'.$row['dob'].'</td>
                                  <td></td>
                                </tr>
                                <tr> 
                                    <!--Row 3-->
                                  <th scope="row">Blood Type:</th>
                                  <td >'.$row['bloodtype'].'</td>
                                  <td></td>
                                </tr>
                                <tr> 
                                    <!--Row 4-->
                                  <th scope="row">Phone No. :</th>
                                  <td >+'.$row['phone'].'</td>
                                  <td> </td>
                                </tr>
                                <tr> 
                                    <!--Row 5-->
                                  <th scope="row">Email:</th>
                                  <td >'.$row['email'].'</td>
                                  <td></td>
                                </tr>
                                <tr> 
                                    <!--Row 6-->
                                  <th scope="row">Address:</th>
                                  <td >'.$row['address'].'</td>
                                  <td></td>
                                </tr>
                                <tr> 
                                    <!--Row 7-->
                                  <th scope="row"></th>
                                  <td >'.$row['address2'].'</td>
                                  <td></td>
                                </tr>
                          </table>
                         <a href="editinfo.php?id=' . $row['user_id'] . '" class="btn btn-primary">Edit</a>
                         <a href="loggedin.php" class="btn btn-light">Return</a>     
                         </div>
                </div>';
}

mysqli_free_result($r);
?>
                <img class="img-fluid w-60 d-none d-sm-block" 
                src="img/bloodlogo4.png" alt="">
                
            </div>
        </div>
    </section>
    



            <!--Footer-->
    <footer class="p-5 bg-dark text-white text-left position-relative">
    <div class="container">
        <p class="lead">Copyright &copy; 2022 Blood Bank Brunei UniKL.FYP2-AmalNaqibah52213118385</p>
    
        <a href="" class="position-absolute bottom-0 end-0 p-5">
            <i class="bi bi-arrow-up-circle h1"></i>
        </a>
    </div>
    </footer>


   
        
      </div>
    </div>
  </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</form>
</body>
</html>